create definer = root@localhost trigger insertBookItems
    after insert
    on book
    for each row
BEGIN
	DECLARE
		i INT  DEFAULT 1;
	WHILE i <= NEW.nrOfCopies do
		INSERT INTO book_item(bookId, dateOfPurchase, status)
		values (NEW.id, null, 'AVAILABLE' );
		SET i := i + 1;
	END WHILE;
END;

